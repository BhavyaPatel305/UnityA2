﻿namespace EasyAI.Navigation.Nodes
{
    /// <summary>
    /// These manually placed will be connected by an agent manager but have no other logic themselves.
    /// </summary>
    public class Node : NodeBase { }
}